
import course from './course';

export default course;
