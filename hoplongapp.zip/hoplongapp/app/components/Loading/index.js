import LoadingCircular from './circular';

export default LoadingCircular;
