const pmathText = {
  titleCourseNew: 'Khóa học mới',
  viewMore: 'Xem thêm',
};

export default pmathText

